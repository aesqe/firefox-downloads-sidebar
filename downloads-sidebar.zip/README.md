# Downloads sidebar web extension

This extension will displays a list of your latest downloads in a sidebar.

## How do I use this?

Open your Firefox sidebar and choose "Downloads" from the top drop-down list.

Be warned: this was made in an afternoon and as such it is nowhere near complete. I do intend to work further on it.